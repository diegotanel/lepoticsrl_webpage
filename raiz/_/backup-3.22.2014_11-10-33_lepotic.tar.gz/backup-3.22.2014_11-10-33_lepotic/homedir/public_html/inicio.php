<h1>Qui&eacute;nes somos</h1>
<p>Somos una empresa familiar radicada en argentina dedicada a la importacion y fabricacion de estuches, bolsas, pa&ntilde;os y exhibidores para relojes, joyas y afines.
  
</p>
<p>Nuestra gran antig&uuml;edad en el sector nos hace conocer las demandas de los clientes mas exigentes. Por lo cual constantemente renovamos nuestro catalogo en base a sus sugerencias.
</p>
<p>Lo mas sactifactorio es que encuentre ese estuche que&nbsp;se asemeje al que imagin&oacute; y para&nbsp;ello trabajamos.&nbsp;Le&nbsp;ofrecemos&nbsp;la posibilidad de impresion en serigraf&iacute;a.</p>
<p>Hacemos envios a todo el pais a traves de expresos, micros, &nbsp;etc a su eleccion.</p>
<div></div>
<div></div>
<center><img src="imagenes/fotos-estuches.png" alt="estuches" width="685" height="245" /></center> 